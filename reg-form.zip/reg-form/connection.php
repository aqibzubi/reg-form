<?php
$conn = mysqli_connect("localhost", "root", "", "form");
if(!$conn){
    die("connection failed");
}

?>